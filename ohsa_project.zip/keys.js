// confidential configuration data
var keys = {
	client_id: "151098849255-l5i0p6sgpqqf7bu2vh9krg8u6k3k3c2e.apps.googleusercontent.com",
	client_secret: "",	// deleted for confidentiality
	redirect_uri: ["http://localhost:8080/UserInfo", "https://ohsa-project.wl.r.appspot.com/UserInfo" ]
};

module.exports = keys;
