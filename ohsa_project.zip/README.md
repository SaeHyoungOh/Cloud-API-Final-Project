# Portfolio Assignment: Final Project
Name: Sae Hyoung Oh
Last Modified: 6/1/2020
Description: 
	User ID can be created at /welcome.
	JWT and the User ID must be copied into Postman before use.
	This cloud API supports CRUD of boats and loads.
	The boats are protected for each user.
	Loads can be loaded to boats.
